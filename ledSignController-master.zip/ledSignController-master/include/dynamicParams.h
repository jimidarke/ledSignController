/****************************************************************************************************************************
  dynamicParams.h
  For ESP8266 / ESP32 boards

  ESP_WiFiManager_Lite (https://github.com/khoih-prog/ESP_WiFiManager_Lite) is a library
  for the ESP32/ESP8266 boards to enable store Credentials in EEPROM/SPIFFS/LittleFS for easy
  configuration/reconfiguration and autoconnect/autoreconnect of WiFi and other services without Hardcoding.

  Built by Khoi Hoang https://github.com/khoih-prog/ESP_WiFiManager_Lite
  Licensed under MIT license
 *****************************************************************************************************************************/

#ifndef dynamicParams_h
#define dynamicParams_h

#include "defines.h"

// USE_DYNAMIC_PARAMETERS defined in defined.h

/////////////// Start dynamic Credentials ///////////////

//Defined in <ESP_WiFiManager_Lite.h>
/**************************************
  #define MAX_ID_LEN                5
  #define MAX_DISPLAY_NAME_LEN      16

  typedef struct
  {
  char id             [MAX_ID_LEN + 1];
  char displayName    [MAX_DISPLAY_NAME_LEN + 1];
  char *pdata;
  uint8_t maxlen;
  } MenuItem;
**************************************/

#if USE_DYNAMIC_PARAMETERS
/*
  #define MAX_BLYNK_SERVER_LEN      34
  #define MAX_BLYNK_TOKEN_LEN       34

  char Blynk_Server1 [MAX_BLYNK_SERVER_LEN + 1]  = "account.duckdns.org";
  char Blynk_Token1  [MAX_BLYNK_TOKEN_LEN + 1]   = "token1";

  char Blynk_Server2 [MAX_BLYNK_SERVER_LEN + 1]  = "account.ddns.net";
  char Blynk_Token2  [MAX_BLYNK_TOKEN_LEN + 1]   = "token2";

  #define MAX_BLYNK_PORT_LEN        6
  char Blynk_Port   [MAX_BLYNK_PORT_LEN + 1]  = "8080";

  #define MAX_MQTT_SERVER_LEN      34
  char MQTT_Server  [MAX_MQTT_SERVER_LEN + 1]   = "mqtt.duckdns.org";

  MenuItem myMenuItems [] =
  {
  { "sv1", "Blynk Server1", Blynk_Server1,  MAX_BLYNK_SERVER_LEN },
  { "tk1", "Token1",        Blynk_Token1,   MAX_BLYNK_TOKEN_LEN },
  { "sv2", "Blynk Server2", Blynk_Server2,  MAX_BLYNK_SERVER_LEN },
  { "tk2", "Token2",        Blynk_Token2,   MAX_BLYNK_TOKEN_LEN },
  { "prt", "Port",          Blynk_Port,     MAX_BLYNK_PORT_LEN },
  { "mqt", "MQTT Server",   MQTT_Server,    MAX_MQTT_SERVER_LEN },
  };
*/

#define MAX_MQTT_SERVER_LEN      34
#define MAX_MQTT_PORT_LEN        6

char MQTT_Server [MAX_MQTT_SERVER_LEN + 1]    = "mqtt";
char MQTT_Port   [MAX_MQTT_PORT_LEN + 1]      = "1883";
char MQTT_User   [MAX_MQTT_SERVER_LEN + 1]    = "";
char MQTT_Pass   [MAX_MQTT_SERVER_LEN + 1]    = "";
char TZ_POSIX    [MAX_MQTT_SERVER_LEN + 1]    = "MST7MDT,M3.2.0/2,M11.1.0/2";

MenuItem myMenuItems [] =
{
  { "mqt", "MQTT Server",   MQTT_Server,    MAX_MQTT_SERVER_LEN },
  { "mqp", "MQTT Port",     MQTT_Port,      MAX_MQTT_PORT_LEN   },
  { "mqu", "MQTT User",     MQTT_User,      MAX_MQTT_SERVER_LEN   },
  { "mqd", "MQTT Pass",     MQTT_Pass,      MAX_MQTT_SERVER_LEN   },
  { "tzp", "TZ Posix",      TZ_POSIX,       MAX_MQTT_SERVER_LEN   }
};

uint16_t NUM_MENU_ITEMS = sizeof(myMenuItems) / sizeof(MenuItem);  //MenuItemSize;

#else

MenuItem myMenuItems [] = {};

uint16_t NUM_MENU_ITEMS = 0;

#endif    //USE_DYNAMIC_PARAMETERS


#endif      //dynamicParams_h
