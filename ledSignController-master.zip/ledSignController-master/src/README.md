Arduino library that controls BetaBrite signs over a serial connection.

You will need a simple serial driver circuit.

The venerable [MAX232](http://en.wikipedia.org/wiki/MAX232) will do nicely.

Note that the reference manual which led to this work is the Alpha Sign Communications Protocol which can be found by searching that phrase in your preferred search engine. It's at revision F as of this writing (5 June 2019) which hasn't been updated since 2006, so it would appear to be pretty stable.

categories:
weather 1
trivia 1
news 5
jokes 5
facts 5


Options List for LED Sign 
amber
automode
balloon
bomb
clock
comprotate
cyclecolors
dontdrinkanddrive
explode
fireworks
fish
flash
green
hold
interlock
newsflash
nosmoking
red
rolldown
rollin
rollleft
rollout
rollright
rollup
rotate
scroll
slide
slots
snow
sparkle
spray
starburst
switch
thankyou
twinkle
welcome
wipedown
wipein
wipeleft
wipeout
wiperight
wipeup
